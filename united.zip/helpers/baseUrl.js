export const BASE_URL = 'http://mathmozocms.test'; // Replace with your actual base URL
