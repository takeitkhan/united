export const BASE_URL = 'https://admin.umbd.net'; // Replace with your actual base URL
